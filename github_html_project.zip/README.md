# GitHub HTML Project

This is a simple HTML/CSS project structure ready to be uploaded and hosted on GitHub Pages.

## How to Use

1. Fork or clone this repo.
2. Push it to your GitHub account.
3. Go to your repository settings > Pages > Set the source to `main` branch and `/ (root)` folder.
4. Your site will be live at `https://yourusername.github.io/repo-name/`.

Enjoy!
